This is the updated version of the SWIRL code, originally
written by Ken Kousen.

To compile the code, 

cd Swirl_Modes
make

The executable, 'swirlF2008', is put in the CodeRun subdirectory,
and reads from the file 'input.data'
